<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Smtp
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Smtp\Controller\Adminhtml\Smtp\AbandonedCart;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\Page;
use Magento\Quote\Model\QuoteRepository;
use Psr\Log\LoggerInterface;
use Magento\Framework\ObjectManagerInterface;

/**
 * Class Savecomment
 * @package Mageplaza\Smtp\Controller\Adminhtml\Smtp\AbandonedCart
 */
class Savecomment extends Action
{
    /**
     * @var QuoteRepository
     */
    protected $quoteRepository;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Registry
     */
    protected $registry;

    protected $objectManager;


    /**
     * Send constructor.
     *
     * @param Context $context
     * @param QuoteRepository $quoteRepository
     * @param LoggerInterface $logger
     * @param Registry $registry
     * @param ObjectManagerInterface $objectManager
     */
    public function __construct(
        Context $context,
        QuoteRepository $quoteRepository,
        LoggerInterface $logger,
        Registry $registry,
        ObjectManagerInterface $objectManager
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->logger = $logger;
        $this->registry = $registry;
        $this->objectManager = $objectManager;

        parent::__construct($context);
    }

    /**
     * @return ResponseInterface|ResultInterface|Page
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id', 0);

        try {
            $quote = $this->quoteRepository->get($id);
            $abandonedcartComment = $this->getRequest()->getParam('abandonedcart_comment');
            $adminUser = $this->objectManager->get('Magento\Backend\Model\Auth\Session')->getUser();
            $abandonedcartCommentBy = $adminUser->getFirstname().' '.$adminUser->getLastname();
            $abandonedcartComment = $abandonedcartComment.' ( '.$abandonedcartCommentBy.' ) ';
            if($quote->getAbandonedcartComment()){
                $previousComment = $quote->getAbandonedcartComment();
                $abandonedcartComment = $previousComment.'<br>'.$abandonedcartComment;
            }
            
            $quote->setAbandonedcartComment($abandonedcartComment);
            $quote->setAbandonedcartCommentBy($abandonedcartCommentBy);
            $quote->save();
            $this->messageManager->addSuccessMessage(__('Abandoned cart comment saved successfully!'));
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage(__('Abandoned cart comment cannot be saved'));
            $this->logger->error($e->getMessage());
        }

        return $this->_redirect('adminhtml/smtp_abandonedcart/view', ['id' => $id]);
    }
}

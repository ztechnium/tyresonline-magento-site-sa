<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Smtp
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Smtp\Block;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Model\Product;
use Magento\Directory\Model\PriceCurrency;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Item;
use Magento\Quote\Model\QuoteFactory;
use Magento\Store\Model\Store;
use Magento\Tax\Helper\Data;
use Magento\Tax\Model\Config;
use Mageplaza\Smtp\Helper\EmailMarketing;

/**
 * Class AbandonedCart
 * @package Mageplaza\Smtp\Block
 */
class AbandonedCart extends Template
{
    /**
     * @var ProductRepositoryInterface
     */
    protected $_productRepository;

    /**
     * @var PriceCurrency
     */
    protected $priceCurrency;

    /**
     * @var Data
     */
    protected $taxHelper;

    /**
     * @var QuoteFactory
     */
    protected $quoteFactory;

    /**
     * @var EmailMarketing
     */
    protected $helperEmailMarketing;

    /**
     * AbandonedCart constructor.
     *
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param PriceCurrency $priceCurrency
     * @param QuoteFactory $quoteFactory
     * @param EmailMarketing $helperEmailMarketing
     * @param array $data
     */
    public function __construct(
        Context $context,
        ProductRepositoryInterface $productRepository,
        PriceCurrency $priceCurrency,
        QuoteFactory $quoteFactory,
        EmailMarketing $helperEmailMarketing,
        array $data = []
    ) {
        $this->_productRepository = $productRepository;
        $this->priceCurrency = $priceCurrency;
        $this->taxHelper = $context->getTaxData();
        $this->quoteFactory = $quoteFactory;
        $this->helperEmailMarketing = $helperEmailMarketing;
        parent::__construct($context, $data);
    }

    /**
     * @return Quote|null
     */
    public function getQuote()
    {
        if ($quoteId = $this->getData('quote_id')) {
            return $this->quoteFactory->create()->load($quoteId);
        }

        return null;
    }

    /**
     * @return EmailMarketing
     */
    public function getHelperEmailMarketing()
    {
        return $this->helperEmailMarketing;
    }

    /**
     * Get items in quote
     *
     * @return Item[]
     */
    public function getProductCollection()
    {
        $items = [];

        if ($quote = $this->getQuote()) {
            return $quote->getAllVisibleItems();
        }

        return $items;
    }

    /**
     * Get subtotal in quote
     *
     * @param bool $inclTax
     *
     * @return float|string
     */
    public function getSubtotal($inclTax = false)
    {
        $subtotal = 0;
        if ($quote = $this->getQuote()) {
            $address  = $quote->isVirtual() ? $quote->getBillingAddress() : $quote->getShippingAddress();
            $subtotal = $inclTax ? $address->getSubtotalInclTax() : $address->getSubtotal();
        }

        return $this->formatPrice($subtotal, $quote ? $quote->getStoreId() : null);
    }

    /**
     * @param int|float $value
     * @param int $storeId
     *
     * @return float|string
     */
    public function formatPrice($value, $storeId)
    {
        return $this->priceCurrency->format(
            $value,
            true,
            PriceCurrency::DEFAULT_PRECISION,
            $storeId
        );
    }

    /**
     * @param Item $item
     *
     * @return string|string[]|null
     */
    public function getProductImage(Item $item)
    {
        $productId = $item->getProductId();
        try {
            /** @var Product $product */
            $product = $this->_productRepository->getById($productId);
            /** @var Store $store */
            $store    = $this->_storeManager->getStore();
            $imageUrl = $store->getBaseUrl(UrlInterface::URL_TYPE_MEDIA) . 'catalog/product' . $product->getImage();

            return str_replace('\\', '/', $imageUrl);
        } catch (NoSuchEntityException $e) {
            return null;
        }
    }

    /**
     * @return Config
     */
    public function getTaxConfig()
    {
        return $this->taxHelper->getConfig();
    }

    public function getAlternativeProductIds()
    {
        $itemCollection = $this->getProductCollection();
        $productIds = array();
        foreach ($itemCollection as $item){
            $productIds[] = $item->getProductId();
        }
        return $productIds;
    }
    public function getAlternativeOne($productId)
    {
        $alternativeProductIds = $this->getAlternativeProductIds();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productCollectionFactory = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
        $productStatus = $objectManager->get('Magento\Catalog\Model\Product\Attribute\Source\Status');
        $productVisibility = $objectManager->get('Magento\Catalog\Model\Product\Visibility');
        $attributeCode = 'parts_category';
        $optionValue = 'Tyres';
        $partsCategory = $this->getOptionIdByLabel($attributeCode,$optionValue);
        $brand = $this->getOptionIdByLabel('mgs_brand','Matrax Tyres');
        $alternativeProductCollection = array();
        $_product = $objectManager->create('Magento\Catalog\Model\Product')->load($productId);
        $width = $_product->getWidth();
        $height = $_product->getHeight();
        $rim = $_product->getRim();
        $alternativeProductCollection = $productCollectionFactory->create()
                ->addAttributeToSelect('*')
                ->addAttributeToFilter('status', ['in' => $productStatus->getVisibleStatusIds()])
                //->addFieldToFilter('entity_id', ['neq' => $_product->getId()])
                ->addFieldToFilter('entity_id', array('nin' => $alternativeProductIds))
                ->setVisibility($productVisibility->getVisibleInSiteIds())
                ->addFieldToFilter('parts_category', $partsCategory)
                ->addFieldToFilter('mgs_brand', $brand)
                ->addFieldToFilter('width', $width)
                ->addFieldToFilter('height', $height)
                ->addFieldToFilter('rim', $rim)
                ->setPageSize(1);
        return $alternativeProductCollection;
        
    }
    public function getAlternativeTwo($productId)
    {
        $alternativeProductIds = $this->getAlternativeProductIds();
        $alternativeOneCollection = $this->getAlternativeOne($productId);

        $altarnativeOneIds = array();

        foreach($alternativeOneCollection as $collection){
            $altarnativeOneIds[] = $collection->getId();
        }
        
        $skipIds = array_unique(array_merge($alternativeProductIds,$altarnativeOneIds));
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productCollectionFactory = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
        $productStatus = $objectManager->get('Magento\Catalog\Model\Product\Attribute\Source\Status');
        $productVisibility = $objectManager->get('Magento\Catalog\Model\Product\Visibility');
        $attributeCode = 'parts_category';
        $optionValue = 'Tyres';
        $partsCategory = $this->getOptionIdByLabel($attributeCode,$optionValue);
        $alternativeProductCollection = array();
        $_product = $objectManager->create('Magento\Catalog\Model\Product')->load($productId);
        $minPrice = $_product->getPrice() - 200;
        $maxPrice = $_product->getPrice() + 200;
        
        $width = $_product->getWidth();
        $height = $_product->getHeight();
        $rim = $_product->getRim();
        $alternativeProductCollection = $productCollectionFactory->create()
                ->addAttributeToSelect('*')
                ->addAttributeToFilter('status', ['in' => $productStatus->getVisibleStatusIds()])
                //->addFieldToFilter('entity_id', ['neq' => $_product->getId()])
                ->addFieldToFilter('entity_id', array('nin' => $skipIds))
                ->setVisibility($productVisibility->getVisibleInSiteIds())
                ->addFieldToFilter('parts_category', $partsCategory)
               // ->addFieldToFilter('category_quality', array('neq' => ''))
                ->addFieldToFilter('width', $width)
                ->addFieldToFilter('height', $height)
                ->addFieldToFilter('rim', $rim)
                ->addPriceDataFieldFilter('%s >= %s', ['final_price', $minPrice])
                ->addPriceDataFieldFilter('%s <= %s', ['final_price', $maxPrice])
                ->addFinalPrice()
                ->setPageSize(3);
        return $alternativeProductCollection;
        
    }
    public function getAlternativeThree($productId)
    {
        $alternativeProductIds = $this->getAlternativeProductIds();
        $alternativeOneCollection = $this->getAlternativeOne($productId);
        $alternativeTwoCollection = $this->getAlternativeTwo($productId);
        
        $altarnativeOneIds = array();
        $altarnativeTwoIds = array();

        foreach($alternativeOneCollection as $collection){
            $altarnativeOneIds[] = $collection->getId();
        }
        foreach($alternativeTwoCollection as $collection){
            $altarnativeTwoIds[] = $collection->getId();
        }
        
        $skipIds = array_unique(array_merge($alternativeProductIds,$altarnativeOneIds,$altarnativeTwoIds));

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productCollectionFactory = $objectManager->create('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
        $productStatus = $objectManager->get('Magento\Catalog\Model\Product\Attribute\Source\Status');
        $productVisibility = $objectManager->get('Magento\Catalog\Model\Product\Visibility');
        $attributeCode = 'parts_category';
        $optionValue = 'Tyres';
        $partsCategory = $this->getOptionIdByLabel($attributeCode,$optionValue);
        $alternativeProductCollection = array();
        $_product = $objectManager->create('Magento\Catalog\Model\Product')->load($productId);
        $width = $_product->getWidth();
        $height = $_product->getHeight();
        $rim = $_product->getRim();
        $alternativeProductCollection = $productCollectionFactory->create()
                ->addAttributeToSelect('*')
                ->addAttributeToFilter('status', ['in' => $productStatus->getVisibleStatusIds()])
                //->addFieldToFilter('entity_id', ['neq' => $_product->getId()])
                ->addFieldToFilter('entity_id', array('nin' => $skipIds))
                ->setVisibility($productVisibility->getVisibleInSiteIds())
                ->addFieldToFilter('parts_category', $partsCategory)
                ->addFieldToFilter('offers', array('neq' => ''))
                ->addFieldToFilter('width', $width)
                ->addFieldToFilter('height', $height)
                ->addFieldToFilter('rim', $rim)
                ->setPageSize(1);
        return $alternativeProductCollection;
        
    }
    public function getOptionIdByLabel($attributeCode,$optionLabel)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productFactory = $objectManager->get('Magento\Catalog\Model\ProductFactory');
        $product = $productFactory->create();
        $isAttributeExist = $product->getResource()->getAttribute($attributeCode);
        $optionId = '';
        if ($isAttributeExist && $isAttributeExist->usesSource()) {
            $optionId = $isAttributeExist->getSource()->getOptionId($optionLabel);
        }
        return $optionId;
    }
    public function getAlternativeProductImage($product)
    {
        try {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $imageHelper = $objectManager->get('\Magento\Catalog\Helper\Image');
            $imageUrl = null;
            $imageUrl = $imageHelper->init($product, 'product_small_image')->keepAspectRatio(true)->resize('365','500')->setImageFile($product->getFile())->getUrl();
            return $imageUrl;
        } catch (NoSuchEntityException $e) {
            return null;
        }
    }
}

<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Smtp
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Smtp\Cron;

use Exception;
use Psr\Log\LoggerInterface;
use Magento\Quote\Model\ResourceModel\Quote\CollectionFactory;
use Magento\SalesRule\Model\Rule;
use Magento\Quote\Model\QuoteRepository;
use Mageplaza\Smtp\Helper\EmailMarketing;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\AreaList;
use Magento\Email\Model\Template;
use Magento\Framework\App\Area;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Registry;
use Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory as RuleCollectionFactory;
use Magento\SalesRule\Model\Rule\Condition\Product\Found;

class SendAbandonedCartEmail
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    protected $objectManager;

    protected $quoteCollectionFactory;

    protected $quoteRepository;

    protected $helperEmailMarketing;

    protected $scopeConfig;

    protected $areaList;

    protected $emailTemplate;

    protected $transportBuilder;

    protected $registry;

    /**
     * ClearLog constructor.
     *
     * @param LoggerInterface $logger
     */
    const CUSTOM_ABANDONEDCART_EMAIL_TEMPLATE  = 'hdwebcore/general/custom_abandonedcart_email_template';

    public function __construct(
        LoggerInterface $logger,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        CollectionFactory $quoteCollectionFactory,
        QuoteRepository $quoteRepository,
        EmailMarketing $helperEmailMarketing,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        AreaList $areaList,
        Template $emailTemplate,
        TransportBuilder $transportBuilder,
        Registry $registry
    ) {
        $this->logger = $logger;
        $this->objectManager = $objectManager;
        $this->quoteCollectionFactory = $quoteCollectionFactory;
        $this->quoteRepository = $quoteRepository;
        $this->helperEmailMarketing = $helperEmailMarketing;
        $this->scopeConfig = $scopeConfig;
        $this->areaList = $areaList;
        $this->emailTemplate = $emailTemplate;
        $this->transportBuilder = $transportBuilder;
        $this->registry = $registry;
        
    }

    /**
     * Clean Email Log after X day(s)
     *
     * @return $this
     */
    public function execute()
    {
        $quoteCollection = $this->quoteCollectionFactory->create();
        $quoteCollection->addFieldToFilter('is_active', 1);
        $quoteCollection->addFieldToFilter('customer_email', ['notnull' => true]);
        $quoteCollection->addFieldToFilter('items_count', ['neq' => 0]);
        $quoteCollection->addFieldToFilter('abandonedcart_email_sent', ['eq' => 0]);
        //echo '<pre>';print_r($quoteCollection->getData());die;
        foreach ($quoteCollection as $quote) {
            $quoteId = $quote->getId();
            $this->sendEmail($quoteId);
        }
        
    }

    public function sendEmail($quoteId)
    {
        $quote = $this->quoteRepository->get($quoteId);
        
        $customerEmail = $quote->getCustomerEmail();
        $customerOrdered =  $this->checkCustomerOrder($customerEmail);
        if($customerOrdered){
            $quote->setAbandonedcartEmailSent(2);
            $quote->setMpSmtpAceSent(1);
            $quote->setAbandonedcartComment('System has checked that Customer has already purchased with different order.');
            $quote->save();
        }else{
            $customerName = $this->helperEmailMarketing->getCustomerName($quote);

            $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
            $name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);

            $from = array('email' => $email, 'name' => $name);
            $templateId  = $this->scopeConfig->getValue(self::CUSTOM_ABANDONEDCART_EMAIL_TEMPLATE, ScopeInterface::SCOPE_STORE);
            if($templateId){
                $recoveryUrl = $this->helperEmailMarketing->getRecoveryUrl($quote);
                $vars = [
                    'quote_id' => $quote->getId(),
                    'customer_name' => ucfirst($customerName),
                    'cart_recovery_link' => $recoveryUrl
                ];
        
                $transport = $this->transportBuilder->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => Area::AREA_FRONTEND, 'store' => $quote->getStoreId()])
                    ->setFrom($from)
                    //->addTo($customerEmail, $customerName)
                    ->addTo($customerEmail)
                    ->setTemplateVars($vars)
                    ->getTransport();
        
                $transport->sendMessage();
                $quote->setAbandonedcartEmailSent(1);
                $quote->setMpSmtpAceSent(1);
                $quote->save();
            }else{
                $this->logger->info('Email template not set for the abandoned cart');
            }
        }
        
    }
    public function checkCustomerOrder($customerEmail){
        $timezoneInterface = $this->objectManager->get('Magento\Framework\Stdlib\DateTime\TimezoneInterface');
        $from = $timezoneInterface->date()->format('Y-m-d H:i:s');
		$now = new \DateTime();		

		$currentDate =  strtotime(date('Y-m-d'));
		
		$pastDate = strtotime("-1 day", $currentDate);
		$from_current_date = date('Y-m-d', $pastDate);
        $futureDate = strtotime("+1 day", $currentDate);
		$to_current_date = date('Y-m-d', $futureDate);
        $hasOrdered = 0;
        $order_collection = $this->objectManager->create('Magento\Sales\Model\Order')->getCollection()
                        ->addAttributeToFilter('customer_email', $customerEmail)
                        ->addAttributeToFilter('status', array('nin' => array('pending','canceled','pending_payment','voided','closed')))
                        ->addFieldToFilter('created_at', ['gteq' => $now->format($from_current_date)])
						->addFieldToFilter('created_at', ['lteq' => $now->format($to_current_date)]);
        //echo '<pre>';print_r($order_collection->getData());
        if(count($order_collection->getData()) > 0){
            $hasOrdered = 1;
        }
        return $hasOrdered;
    }
}

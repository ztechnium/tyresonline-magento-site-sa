<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Smtp
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Smtp\Cron;

use Exception;
use Psr\Log\LoggerInterface;
use Magento\Quote\Model\ResourceModel\Quote\CollectionFactory;
use Magento\SalesRule\Model\Rule;
use Magento\Quote\Model\QuoteRepository;
use Mageplaza\Smtp\Helper\EmailMarketing;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\AreaList;
use Magento\Email\Model\Template;
use Magento\Framework\App\Area;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Registry;
use Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory as RuleCollectionFactory;
use Magento\SalesRule\Model\Rule\Condition\Product\Found;

class SendAbandonedCartEmailRemind
{
    /**
     * @var LoggerInterface
     */
    protected $logger;

    protected $objectManager;

    protected $quoteCollectionFactory;

    protected $quoteRepository;

    protected $helperEmailMarketing;

    protected $scopeConfig;

    protected $areaList;

    protected $emailTemplate;

    protected $transportBuilder;

    protected $registry;

    /**
     * ClearLog constructor.
     *
     * @param LoggerInterface $logger
     */

    const CUSTOM_ABANDONEDCART_REMIND_EMAIL_TEMPLATE  = 'hdwebcore/general/custom_abandonedcart_remind_email_template';

    public function __construct(
        LoggerInterface $logger,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        CollectionFactory $quoteCollectionFactory,
        QuoteRepository $quoteRepository,
        EmailMarketing $helperEmailMarketing,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        AreaList $areaList,
        Template $emailTemplate,
        TransportBuilder $transportBuilder,
        Registry $registry
    ) {
        $this->logger = $logger;
        $this->objectManager = $objectManager;
        $this->quoteCollectionFactory = $quoteCollectionFactory;
        $this->quoteRepository = $quoteRepository;
        $this->helperEmailMarketing = $helperEmailMarketing;
        $this->scopeConfig = $scopeConfig;
        $this->areaList = $areaList;
        $this->emailTemplate = $emailTemplate;
        $this->transportBuilder = $transportBuilder;
        $this->registry = $registry;
        
    }

    /**
     * Clean Email Log after X day(s)
     *
     * @return $this
     */
    public function execute()
    {
        $now = new \DateTime();

        $currentDate =  strtotime(date('Y-m-d H:i:s'));
		$pastDate = strtotime("-1 day", $currentDate);
        $pastDate_subject = date('Y-m-d', $pastDate);
        //echo $pastDate_subject;die;
        $quoteCollection = $this->quoteCollectionFactory->create();
        $quoteCollection->addFieldToFilter('is_active', 1);
        $quoteCollection->addFieldToFilter('customer_email', ['notnull' => true]);
        $quoteCollection->addFieldToFilter('items_count', ['neq' => 0]);
        $quoteCollection->addFieldToFilter('abandonedcart_email_sent', ['eq' => 1]);
        $quoteCollection->addFieldToFilter('updated_at', ['lteq' => $now->format($pastDate_subject.' H:i:s')]);
        //$quoteCollection->addFieldToFilter('updated_at', ['gteq' => $now->format('Y-m-d H:i:s')]);
        //echo '<pre>';print_r($quoteCollection->getData());die;
        foreach ($quoteCollection as $quote) {
            $quoteId = $quote->getId();
            $this->sendEmail($quoteId);
        }
    }

    public function sendEmail($quoteId)
    {
        $quote = $this->quoteRepository->get($quoteId);
        
        $customerEmail = $quote->getCustomerEmail();
        $customerName = $this->helperEmailMarketing->getCustomerName($quote);

        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);

        $from = array('email' => $email, 'name' => $name);
        $templateId  = $this->scopeConfig->getValue(self::CUSTOM_ABANDONEDCART_REMIND_EMAIL_TEMPLATE, ScopeInterface::SCOPE_STORE);
        if($templateId){
            $recoveryUrl = $this->helperEmailMarketing->getRecoveryUrl($quote);
            $vars = [
                'quote_id' => $quote->getId(),
                'customer_name' => ucfirst($customerName),
                'cart_recovery_link' => $recoveryUrl
            ];

            /*$areaObject = $this->areaList->getArea($this->emailTemplate->getDesignConfig()->getArea());
            $areaObject->load(Area::PART_TRANSLATE);*/

            $transport = $this->transportBuilder->setTemplateIdentifier($templateId)
                ->setTemplateOptions(['area' => Area::AREA_FRONTEND, 'store' => $quote->getStoreId()])
                ->setFrom($from)
                //->addTo($customerEmail, $customerName)
                ->addTo($customerEmail)
                ->setTemplateVars($vars)
                ->getTransport();

            $transport->sendMessage();
            $quote->setAbandonedcartEmailSent(2);
            $quote->setMpSmtpAceSent(1);
            $quote->save();
        }else{
            $this->logger->info('Email template not set for the abandoned cart remind');
        }
    }
}
